package com.example.amirov_zachet

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var cityName: EditText;
    private lateinit var city1: TextView;
    private lateinit var temp1: TextView;
    private lateinit var date: TextView;
    private lateinit var datetime: TextView;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cityName = findViewById(R.id.cityName);
        city1 = findViewById(R.id.city);
        temp1 = findViewById(R.id.tempText);
        date = findViewById(R.id.dateText);
        datetime = findViewById(R.id.datetimeText);
    }
    private fun getResult(city: String) {
        if(city.isNotEmpty() && city != null) {
            var key = "b97fcad3c78c4135a9a102524230811"
            var url = "https://api.openweathermap.org/data/2.5/weather?q=$city" +
                    "&appid=$key&lang=ru&units=metric";

            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                Request.Method.GET,
                url,
                {
                        response ->
                    val obj = JSONObject(response)
                    val name = obj.getString("name")
                    val main = obj.getJSONObject("main")
                    city1.text = "Название: $name";
                    temp1.text = "Температура: " + main.getString("temp").toString()
                    date.text = "Дата: " + main.getString("date").toString()

                    val time = obj.getJSONObject("date")
                    datetime.text = "Время суток: " + time.getString("datetime").toString()

                    cityName.text = null;
                },
                {
                    var sn =  Snackbar.make(findViewById<View>(android.R.id.content),
                        "Введите название города правильно!", Snackbar.LENGTH_LONG)

                    sn.setActionTextColor(Color.RED);
                    sn.show();
                }
            )

            queue.add(stringRequest)
        }
        else {
            var sn =  Snackbar.make(findViewById<View>(android.R.id.content),
                "Введите название города!", Snackbar.LENGTH_LONG)

            sn.setActionTextColor(Color.RED);
            sn.show();
        }
    }

    fun searchCity(view: View) {
        getResult(cityName.text.toString())
    }
}